pip install -r requirements.txt -t python/

zip -r blurhash.zip .
