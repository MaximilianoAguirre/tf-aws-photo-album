pip install -r requirements.txt -t python/

zip -r wand.zip .

rm -r python/
